(function (){
    var arr = [0.3, 0.2, Math.random()].sort((v1, v2) => v1 - v2);
    console.log(arr);
})();
