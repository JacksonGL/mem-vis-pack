# WHICH Command - Node Version Switcher

    nvs which [version]

Shows the path to a specified local node version, or the current version in the PATH if a version is not specified.
